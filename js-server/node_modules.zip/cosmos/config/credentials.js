 const credentials = {
    "endpoint": "wss://hack19.gremlin.cosmos.azure.com:443/",
    "database": "ankhokha",
    "collection": "ankhokha1",
    "primaryKey": "RBU8kYZvSVsG91uFUjVCnrwjrKvt5lk4yJmjlDoSipaAX8nHRGeIK4hpncdpRShyg9AV5wY6V0YuRmJQD2mKsQ=="
}

module.exports.creds = credentials;
